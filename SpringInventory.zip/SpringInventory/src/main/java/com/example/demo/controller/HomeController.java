package com.example.demo.controller;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.model.Fruits;

@RestController
@RequestMapping("/")

public class HomeController {


	private List<Fruits> list;

	public HomeController() {
		super();
		list=new ArrayList<Fruits>();
		list.add(new Fruits("Apples", 3));
		list.add(new Fruits("Oranges", 4));
		list.add(new Fruits("Pomegranates", 5));
	}

	@GetMapping("/inventory")
	public List<Fruits> getFruitDetails(){
			return list;
	}
	
	@GetMapping("/inventory/{fruitName}")
	public Fruits getFruitDetails(@PathVariable String fruitName){
		for(Fruits fruit: list) {
			System.out.println(fruit.getName());
			if(fruit.getName().equals(fruitName))
				return fruit;
			
		}
		
		return null;
	}
	
	
	@PostMapping("/inventory")
	public List<Fruits> replaceInventory(@RequestBody Fruits fruit) {
		list.add(fruit);	
		return list;
	 		}
	
	
	
	@PutMapping("/inventory/{fruitId}")
	public List<Fruits> updateFruit(@RequestBody Fruits fruits, @PathVariable String fruitId) {
		 for(Fruits fruit : list) {
			    if(fruit.getName().equals(fruitId)) {
			        fruit.setName(fruits.getName());
			           }
			}
		return list;
	}
	
	@DeleteMapping("/inventory/{fruitName}")
	public List<Fruits> deleteFruit(@PathVariable String fruitName){
		
		for(Fruits fruit: list) {
			if(fruit.getName().equals(fruitName)) {
				list.remove(fruit);
				return list;
			}
				
		}
		return list;
		
	}
	
	@DeleteMapping("/inventory")
	public List<Fruits> deleteAll(){
		for(Fruits fruit: list) {
		list.remove(fruit);
		return list;
		}
		return null;
	}
}
